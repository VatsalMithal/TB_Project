import streamlit as st
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from PIL import Image
import cv2

# === Load the best trained model ===
MODEL_PATH = '../Model/VGG16_best_model (1).h5'
model = load_model(MODEL_PATH)

# === App UI ===
st.set_page_config(page_title="TB Detection from Chest X-rays", layout="centered")
st.title("🩺 Tuberculosis Detection from X-ray Images")
st.markdown("Upload a chest X-ray image and the AI will predict whether the patient has **Tuberculosis (TB)** or not.")

uploaded_file = st.file_uploader("Choose a chest X-ray image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # Display uploaded image
    img = Image.open(uploaded_file)
    st.image(img, caption='Uploaded Chest X-ray', use_column_width=True)

    # Preprocess image
    img = img.convert("RGB")
    img = img.resize((224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = img_array / 255.0

    # Predict
    prediction = model.predict(img_array)[0][0]
    label = "🟢 Normal" if prediction < 0.5 else "🔴 Tuberculosis (TB)"
    confidence = (1 - prediction) if prediction < 0.5 else prediction

    # Display result
    st.subheader("Prediction Result")
    st.success(f"**{label}**")
    st.info(f"Model Confidence: {confidence*100:.2f}%")

    st.caption(f"Raw model score: {prediction:.4f}")

else:
    st.warning("Please upload a valid chest X-ray image.")
